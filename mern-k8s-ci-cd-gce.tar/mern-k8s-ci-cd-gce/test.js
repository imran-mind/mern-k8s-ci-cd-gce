function seg(){
    let arr = ['*','&','#','?','&','#','?','#','&','*','&']
    let map = {}
    for(let i=0; i<arr.length; i++){
        console.log(map[arr[i]])
        if(map[arr[i]]){
            map[arr[i]] =  ++map[arr[i]]
        }else{
            map[arr[i]] = 1
        }
    }
    console.log(map)
    let newarr = [];
    let un = Array.from(new Set(arr));
    for(let i=0; i<un.length; i++){
      const item = arr[i];
      if(map[item]){
          let n = []
          for(let j =0; j< map[item]; j++ ){
              n.push(item);
          }
          newarr = [...newarr,...n];
      }
    }
    console.log(newarr)
}
seg()
  